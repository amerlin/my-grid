import React from 'react';

export const NotFoundPage = () => {
    return <div>Pagina non trovata</div>
}