import React from 'react';

export const CustomersSearch = ()=>{
    return (
        <div>Customer Search</div>
    );
}