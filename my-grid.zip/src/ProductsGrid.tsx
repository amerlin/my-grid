import React from 'react';

export const ProductsGrid = ()=>{
    
    return (
        <div>Products Grid</div>
    )

}