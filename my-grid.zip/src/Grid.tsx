import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import { getProductsAsync, ProductData } from './Products';
import { ProductList } from './ProductsList';

export const Grid = () => {

    const pulsante001onClick = () => {
        console.log("pulsante cliccato");
    }
    
    React.useEffect(()=>{
        const getP = async()=>{
            const prod = await getProductsAsync();
            setQuestions(prod);
            setProductsLoading(false);
        };
        getP();
    },[]);

    //imposta la variabile products
    const [
        products,
        setQuestions,
    ] = React.useState<ProductData[]>([]);
    
    //imposto il valore del loader
    const [
        productsLoading,
        setProductsLoading
    ] = React.useState(true);


    const columns = [{
        dataField: 'productId',
        text: 'Product ID'
      }, {
        dataField: 'description',
        text: 'Product Name'
      }, {
        dataField: 'price',
        text: 'Product Price'
      }];

    return (
        <div className="container">
            <div className="row">
                <button type="button" className="btn btn-primary" onClick={pulsante001onClick} >Pulsante001</button>
            </div>
            <div className="row">&nbsp;</div>
            <div className="row">
                <BootstrapTable keyField='id' data={products} columns={columns}
                    striped
                    hover
                    condensed />
            </div>
        </div>
    )


}
