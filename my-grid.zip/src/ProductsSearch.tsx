import React from 'react';


export const ProductsSearch = ()=>{
    return (
        <div>Products Search </div>
    );
}